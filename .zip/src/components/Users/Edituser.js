import React,{useState ,useEffect} from "react";
import axios from "axios";
import {useNavigate, useParams } from "react-router-dom";
// import { wait } from "@testing-library/user-event/dist/utils";
// 

const Edituser = ()=>{
   let history = useNavigate();
  const  {id}= useParams();
     
   console.log("from id ",id);
   const [name ,setName]=useState("")
   const [username ,setUsername]=useState("")
   const [email ,setEmail]=useState("")
   const [phone,setPhone]=useState("")
   const [websitename ,setWebsitename]=useState("")

  
useEffect(()=>{

  // axios.get(`http://localhost:3000/users/${id}`).then((res)=>{
    axios.get(`https://jsonplaceholder.typicode.com/users/${id}`).then((res)=>{
    console.log("res=== id",res.data);
    setName(res.data.name);
    setUsername(res.data.username);
    setEmail(res.data.email);
    setPhone(res.data.phone);
    setWebsitename(res.data.websitename)
  }).catch((err)=>{
    console.log("error",err)
  })
},[])  
   
  const formSubmit= e =>{  
  const  user ={
      name:name,   
      username:username,
      phone:phone,
      websitename:websitename,
      email:email
    };
     console.log("form data ",user);
     e.preventDefault ();
     axios.put(`https://jsonplaceholder.typicode.com/users/${id}`,user).then((res)=>{
     console.log("update",res);
     if(res.status===200){
       history('/')
     }
     
     }).catch((err)=>{
     console.log("error",err)
     });   
     }

  return(
  <div className="container">
   <div className="w-75 mx-auto shadow p-5">  
    <h2 className="text-center mb-4 "> Edit user</h2> 
  
       <form onSubmit={(e) => formSubmit(e)}>
      <div className="from-group">
      <input type="text" 
      className="from control form-control-lg" 
      placeholder="Enter your Name"
      value={name}
      onChange={(e)=>setName(e.target.value)}
       />
      </div>
  
      <div className="from-group">
      <input type="text" 
      className="from control form-control-lg"
      placeholder="Enter your UserName"
      name="username"
      value={username}
      onChange={(e)=>setUsername(e.target.value)}
       />
      </div>
  
      <div className="from-group">
      <input type="text" 
      className="from control form-control-lg"
      placeholder="Enter your E-mail Addres"
      name="email"
      value={email}
      onChange={(e)=>setEmail(e.target.value)}
       />
      </div>
  
      <div className="from-group">
      <input type="text" 
      className="from control form-control-lg"
      placeholder="Enter your Phone Number"
      name="phone"
      value={phone}
      onChange={(e)=>setPhone(e.target.value)}
       />
      </div>
  
      <div className="from-group">
      <input type="text" 
      className="from control form-control-lg"
      placeholder="Enter your Website Name"
      name="websitename"
      value={websitename}
      onChange={(e)=>setWebsitename(e.target.value)}
       />
      </div>
      
    <button className="btn btn-danger btn-block">Updateuser </button>
      </form>
   
       </div>
       </div>

)
}
export default Edituser;