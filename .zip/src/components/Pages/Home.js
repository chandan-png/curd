import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";


const Home = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get("https://jsonplaceholder.typicode.com/users")
      .then(function (response) {
        console.log("=====", response.data);
        setData(response.data.reverse());
      })
      .catch((error) => console.log(error));
  }, []);

  // const deleteUsers =  id =>{
  //  axios.delete('http://localhost:3000/users/${id}');

  //  axios.delete(`http://localhost:3000/users/${id}`,user).then((res)=>{
  // console.log("update",res);
  // loadUsers();
  //  });
  //  const deleteUsers = id => {
  // axios.delete('http://localhost:3000/users/${id}`);
  // }

  
  // e.preventDefault();
  axios
    .delete("https://jsonplaceholder.typicode.com/users/")
    .then((res) => {
      console.log("update", res);
      if (res.status === 200) {
      }
    })
    .catch((err) => {
      console.log("error", err);
    }); 

  //
  // const listItems = data.map((item) =>
  // <li>{ item.name } {item.email} {item.username} </li>
  // );

  return (
    <div>
      <div>React & Axios api</div>

      <table class="table border shadow">
        <thead class="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th> 
            <th scope="col">Username</th>
            <th scope="col">email</th>
            <th>Action</th>
          </tr>
        </thead>
        <thead>
          {data.map((users, index) => (
            <tr>
              <th scope="row">{index + 1}</th>
              <td> {users.name}</td>
              <td> {users.username}</td>
              <td> {users.email}</td>
              <td>
                {users.id}
                <button class="btn btn-primary mr-2">View</button>
                <Link
                  type="button"
                  className="btn btn-primarymr-2"
                  to={`/Users/edit/${users.id}`}
                >
                  Edit
                </Link>
                {/*<Link class="btn btn-danger"onClick={()=> deleteUsers(users.id)}>Delete</Link>*/}

                <button class="btn btn-danger mr-2">Delete</button>
              </td>
            </tr>
          ))}
        </thead>
      </table>
    </div>
  
  )

};
export default Home